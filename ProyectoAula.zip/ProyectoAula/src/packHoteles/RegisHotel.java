/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package packHoteles;

/**
 *
 * @author SARA
 */
public class RegisHotel {
    private String IDhotel;
    private String nombre;
    private String ofrece;
    private String direccion;
    private String correo;
    private String telefono;

    // Getters y setters
    public String getIDhotel() {
        return IDhotel;
    }

    public void setIDhotel(String IDhotel) {
        this.IDhotel = IDhotel;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getOfrece() {
        return ofrece;
    }

    public void setOfrece(String ofrece) {
        this.ofrece = ofrece;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }
}
