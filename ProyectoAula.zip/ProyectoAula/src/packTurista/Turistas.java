
package packTurista;

import java.time.zone.ZoneOffsetTransitionRule;


public class Turistas {
 
    String IDhotel;
    String NombreT;
    String ApellidoT;
    String TID;
    String IDTurista;
    String TipoReser;
    String Reserva;
    
    
    public Turistas() {
        
    }
    
    public Turistas(String IDh, String nombreT, String ApellidoT, String Tide,String IDT, String Reser, String Treser ) {
        this.IDhotel = IDh;
        this.NombreT = nombreT;
        this.ApellidoT = ApellidoT;
        this.TID = Tide;
        this.IDTurista =  IDT;
        this.TipoReser = Treser;
        this.Reserva = Reser;
        
        
    }
    


    public String getNdocument() {
        return IDhotel;
    }

    public void setNdocumento(String Ndocumento) {
        this.IDhotel = IDhotel;
    }

    public String getnombreM() {
        return NombreT;
    }

    public void setnombreM(String nombreM) {
        this.NombreT = nombreM;
    }

    public String getColor() {
        return ApellidoT;
    }

    public void setColor(String color) {
        this.ApellidoT = color;
    }

    public String getTipoReser() {
        return TipoReser;
    }

    public void setTipoReser(String Tsangre) {
        this.TipoReser = TipoReser;
    }
    
    public String getTvida() {
        return IDTurista;
    }
    
    public void setTvida(String Tvida) {
        this.IDTurista = Tvida;
    }

    public String getReserva() {
        return Reserva;
    }

    public void setReserva(String especie) {
        this.Reserva = Reserva;
    }
    public String getTide(){
    return TID; 
    }
    public void setTide(String Tide){
    this.TID = Tide;
    }

    @Override
    public String toString() {
        return "Mascotas{" + "Id Hotel="+IDhotel + ", nombreT=" + NombreT + ", Apellido Turista=" + ApellidoT + ", Tipo de Reserva=" + TipoReser + ", ID de turista "+ IDTurista+ ", Nª De Habitacion=" + Reserva +", Tipo de Identificacion"+ TID+ '}';
    }
  
    
}